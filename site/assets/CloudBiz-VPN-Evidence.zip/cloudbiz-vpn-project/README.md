# CloudBiz — AWS Hybrid Networking Lab

A personal cloud-networking project connecting a home test host to an AWS EC2 private address through an Ubuntu strongSwan router and AWS Site-to-Site VPN.

**Completed and tested on 30 October 2026; the temporary VPN was then deleted and EC2 stopped.** The project is documented for review and rebuilding. It is not currently running.

[Validation report](VALIDATION.md) · [Sanitized evidence](evidence/) · [Rebuild examples](config-examples/)

Final test: **334 HTTP 200 responses / 347 observations**, with **13 timeouts in one transition** and a **27.81-second gap between successful probes**. Each tunnel passed private traffic independently; both recovered. This is functional failover with a measured interruption, not zero downtime.

## What this project demonstrates

- IKEv2/IPsec configuration and troubleshooting behind a home NAT router.
- Linux VTI routing, packet marks, forwarding controls, and AWS return routes.
- Validation of application traffic and tests initiated from both networks.
- Controlled tunnel shutdown and recovery, with measured traffic continuity.
- Credential hygiene, cost controls, and separation of a lab from existing portfolio infrastructure.

This is a lab, not a production deployment or an employer project. Configuration changes were prepared with AI assistance and reviewed through actual command output and traffic tests. Interview explanations should reflect the work the author can reproduce and explain.

## Architecture and boundaries

![Tested architecture](architecture.svg)

| Component | Actual lab configuration |
|---|---|
| AWS Region | `us-east-1` |
| VPC | `10.20.0.0/16`, two public and two private subnets |
| Test workload | Existing web EC2, private IP `10.20.1.108`, in a **public subnet** |
| AWS gateway | Virtual Private Gateway attached to the project VPC |
| Customer Gateway | Definition of the home router's public IPv4; address omitted |
| VPN | Standard, non-accelerated, static routing; two IPsec tunnels |
| Home LAN | `192.168.1.0/24`; Mac test host `.25`, Ubuntu router `.203` |
| Home router | Spectrum NAT; router configuration/default internet route unchanged |
| Ubuntu | Ubuntu 24.04 ARM64, UTM on MacBook Pro M1 Max; strongSwan 5.9.13 |
| Tunnel 1 inside | AWS `169.254.134.41`, Ubuntu `169.254.134.42/30`; VTI key/mark `100` |
| Tunnel 2 inside | AWS `169.254.9.105`, Ubuntu `169.254.9.106/30`; VTI key/mark `200` |
| Interface settings | MTU 1400; TCP MSS clamp 1360 |
| AWS return path | `192.168.1.0/24 → VGW` in the test workload's public route table |
| Home test-host path | Mac route `10.20.0.0/16 → 192.168.1.203` |

The private subnet route table was not modified. No private-subnet workload or database was deployed or tested. A database security group is not a deployed database. The separate portfolio stack was not changed.

AWS can send return traffic over a different tunnel from the outbound path. Both interfaces have narrow forwarding allowances; Linux reverse-path filtering is configured to tolerate the observed asymmetric path.

## Route and security design

- An up/down hook installs a VPC route only while that tunnel's CHILD SA is installed: primary VTI metric 100, secondary metric 200.
- A destination policy rule sends VPC traffic to the main routing table, ahead of the stale automatic strongSwan table-220 route.
- A high-metric blackhole for the project CIDR prevents fallback to the home internet default route when no tunnel route exists.
- A dedicated forwarding chain allows only the designated Mac/EC2 pair, TCP 80 and ICMP, through either VTI. Other forwarded traffic is dropped.
- IKE/NAT-T input is restricted to the AWS tunnel endpoints. Only encrypted incoming UDP-4500 packets receive endpoint-specific marks; plaintext VPC traffic must not be premarked.
- A proof HTTP listener on Ubuntu port 9000 is restricted to the EC2 private address. It serves a harmless marker, not the user's home directory.
- The EC2 security group has no SSH ingress. AWS Systems Manager provides test administration through a temporary instance role.
- Existing web HTTP/HTTPS rules were preserved. The endpoint is a web server in a public subnet; private test traffic was addressed to its private IP.

No private key or PSK belongs in a repository, screenshot, README, terminal transcript, or ZIP. Previously exposed PSKs were rotated; the rebuilt connection received fresh keys.

## Learning and implementation history

| Day | Work and evidence |
|---|---|
| 16 | Existing VPN and Ubuntu setup inspected; initial resource/configuration baseline captured. |
| 17 | Replaced exposed PSKs; corrected GCM proposal syntax; authenticated IKE and CHILD SA; verified AWS tunnel status. |
| 18 | Added VTIs, narrow forwarding, test-host and AWS return routes; verified private HTTP/ICMP in both directions and a 1400-byte IPv4 packet; private SSH remained blocked. |
| 19 | First failover attempt failed actual Mac traffic despite established SAs. Identified recurring forecast-plugin marking rules. Rebuilt the deleted temporary VPN, disabled forecast, and reran baseline tests. Final validation passed traffic through each tunnel and verified recovery, with the measured interruption reported below. |
| 20 | Complete: sanitized evidence and rebuild examples reviewed; VPN deletion, EC2 stop, temporary IAM/rule/route removal, local cleanup, and audit-key retirement verified. |

The original connection was deleted on 27 October (Chicago time) at the user's request to stop costs. On 30 October, a new temporary connection was created for final validation. Its public endpoints and PSKs changed; the old configuration was not reused blindly.

## Problems, evidence, and resolutions

### Negotiation and service readiness

The accepted strongSwan proposals are `ike=aes256gcm16-prfsha384-ecp384!` and `esp=aes256gcm16-ecp384!`. GCM is authenticated encryption; ESP does not need an additional separate integrity transform. NAT traversal uses UDP 4500.

An immediate `ipsec statusall` call after restarting the daemon returned a nonzero status before the control socket was ready. A later readiness check showed both SAs installed. The resume script stopped after its configuration changes, so it was not rerun blindly. This script error is separate from authentication failure.

### Tunnel UP did not mean application traffic worked

The first 27 October failover run observed 189 Mac HTTP requests and zero successes. Legacy mangle rules premarked plaintext traffic for the VPC, causing it to bypass the intended VTI forwarding path and hit the forwarding guard. Removing the rules once restored traffic, but tunnel events recreated them.

The loaded **forecast** plugin creates PREROUTING/OUTPUT marks for marked CHILD SAs. Its strongSwan 5.9.13 source matched the observed rules. Disabling forecast and restarting the daemon removed the owner of the recurring rules. Only the known project rules were retired; the firewall was not globally flushed. The unrelated connmark plugin was not disabled on an unproven assumption.

### Provisioning and telemetry lag

The first test after rebuilding the connection timed out while AWS was finishing provisioning. A subsequent full baseline test passed private HTTP, ICMP, and AWS-origin requests. The failed test was retained privately rather than silently overwritten. AWS telemetry can lag observed traffic; resource state, SAs, routes, counters, and actual requests are assessed together.

## Rebuild guide

The files in `config-examples/` are sanitized learning examples, not a one-command production installer. Review your environment before applying them.

1. Inventory the VPC, subnet associations, gateway attachment, EC2 state, security groups, routes, LAN IPs, and WAN address. Keep the portfolio separate.
2. Approve a bounded spend and prepare cleanup. Create one standard static VPN using the existing CGW/VGW. Add the home CIDR to its static routes.
3. Obtain the new endpoint/inside addresses. Generate fresh per-tunnel PSKs and install them in root-owned mode-0600 secret files through a secure channel.
4. Configure strongSwan proposals, NAT-T, marks, and route hooks. Disable the optional forecast plugin for this VTI design. Validate daemon readiness after restart.
5. Create keyed VTI interfaces, inside addresses, MTU, narrow incoming encrypted-packet marks, forwarding/MSS rules, explicit VPC routes, and a fail-closed fallback.
6. Add only the project home-return route in the workload's route table. Add only the project VPC route on the designated home test host.
7. Start the existing test EC2 within the approved window. Verify SSM, application health, no public SSH, and a scheduled shutdown.
8. Verify baseline, each tunnel alone, route withdrawal, recovery, actual traffic, and counters. Preserve unsuccessful tests and explain them.
9. Capture sanitized evidence, delete the temporary VPN, stop EC2, remove temporary lab-only access/routing, and verify final state.

## Useful commands and what they prove

```bash
# Control plane; no PSKs printed
sudo ipsec statusall
sudo journalctl -u strongswan-starter --since '10 minutes ago'

# Route choice and interface health
ip route get 10.20.1.108
ip route show 10.20.0.0/16
ip rule show
ip -s link show cloudbiz-vti1
ip -s link show cloudbiz-vti2

# Detect the conflicting legacy marks without exporting encryption keys
sudo iptables-legacy-save -t mangle
sudo iptables -nvL CLOUDBIZ-FWD

# Private application test from the designated home host
curl --interface 192.168.1.25 --max-time 12 -w '\nHTTP=%{http_code}\n' http://10.20.1.108/
ping -c 4 10.20.1.108

# Linux MTU test: 1372 payload + 20 IP + 8 ICMP = 1400 bytes
ping -M do -s 1372 -c 3 10.20.1.108
```

Do not publish raw `ip xfrm state`: it can expose encryption key material. Use sanitized SA status, policy summaries, and counters instead. Read AWS VPN responses through a restricted query; full responses can contain PSKs and credential-bearing XML.

## Monitoring

The lab uses a five-second local health collector and strongSwan/system journals. Independent observation records private HTTP responses during each failover phase, AWS-origin tests, route snapshots, and AWS tunnel telemetry. Native `AWS/VPN` metrics (`TunnelState`, `TunnelDataIn`, `TunnelDataOut`) supplement actual traffic tests. No paid alarm or new CloudWatch log group is implied unless explicitly listed in evidence.

## Cost and lifecycle

The approved session is limited to two hours. A local deadline guard targets deletion of this session's exact VPN and stopping the existing EC2; an independent SSM shutdown is scheduled on EC2. These controls are verified through actual results, not treated as a guarantee if the host loses connectivity.

Estimated standard VPN service cost is $0.05 per connection-hour plus two public IPv4 addresses at $0.005 each/hour. A t3.micro test instance and its temporary public IPv4 add about $0.0154/hour. Together: about **$0.1508 for two hours**, before transfer, EBS, rounding, and other account resources. VPN charges continue while provisioned even when both tunnels are DOWN. Deleting the VPN is required to stop its connection charge.

Stopping EC2 does not delete EBS. Retained EBS and unrelated portfolio resources can continue accruing charges. AWS billing data is delayed; this project's estimates are not the whole-account bill.

## Interview explanation

“I combined my network-operations background with an AWS/Linux lab. I configured a static Site-to-Site VPN behind NAT, built VTI routing, restricted forwarding, and tested private application traffic from both sides. When SAs were UP but requests failed, I followed routes, packet marks, and firewall counters to a plugin that recreated conflicting rules. I corrected the source and validated the result with real traffic. I controlled costs by using a bounded session and tearing down the temporary VPN.”

The final validation report confirms functional failover with a measured interruption. This project demonstrates troubleshooting and hybrid networking; it does not, by itself, prove production DevOps, Kubernetes administration, or CI/CD delivery experience.

## Sources

- [AWS VPN pricing](https://aws.amazon.com/vpn/pricing/)
- [AWS public IPv4 pricing](https://aws.amazon.com/vpc/pricing/)
- [AWS VPN monitoring](https://docs.aws.amazon.com/vpn/latest/s2svpn/monitoring-cloudwatch-vpn.html)
- [strongSwan route-based VPN](https://docs.strongswan.org/docs/latest/features/routeBasedVpn.html)
- [strongSwan forecast plugin](https://docs.strongswan.org/docs/latest/plugins/forecast.html)
- [forecast listener, version 5.9.13](https://github.com/strongswan/strongswan/blob/5.9.13/src/libcharon/plugins/forecast/forecast_listener.c)

## Final lifecycle verification

- Temporary VPN: API state `deleted`.
- Existing EC2: `stopped`, no public IPv4, temporary instance profile removed.
- Temporary SSM role/profile: verified absent.
- Five lab-only security-group rules and home return route removed; original web rules and local/default VPC routes preserved.
- Ubuntu: project VTIs, forwarding guard, incoming marks, MSS rules and priority-100 project rule removed; IPv4 forwarding restored to 0; lab units disabled; proof listener stopped. LAN SSH and the home default route preserved.
- Mac project route removed. Dedicated temporary SSH key removed and authentication with that key verified rejected.
- VPC, VGW, CGW, EC2 and its encrypted 8 GiB gp3 EBS volume retained. EBS remains chargeable; the separate portfolio is preserved. Billing updates can lag teardown.

The diagram depicts the topology during validation, not the final decommissioned state. Root-only historical backups were excluded from this package.
