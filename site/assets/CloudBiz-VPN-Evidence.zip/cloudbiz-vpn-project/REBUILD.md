# Rebuild command reference

Run only after reviewing the current environment, receiving a new spend approval, and setting a cleanup deadline. All `<...>` fields must be replaced. This file contains no PSKs, account credentials, or private SSH keys. The tested baseline is strongSwan 5.9.13 on Ubuntu 24.04 ARM64; review current vendor documentation before reproducing it on another version.

## 1. Inventory before changes

```bash
aws ec2 describe-vpn-gateways --vpn-gateway-ids <VGW_ID> --region us-east-1
aws ec2 describe-customer-gateways --customer-gateway-ids <CGW_ID> --region us-east-1
aws ec2 describe-route-tables --route-table-ids <TEST_ROUTE_TABLE_ID> --region us-east-1
aws ec2 describe-security-groups --group-ids <TEST_SG_ID> --region us-east-1
ip -4 address
ip route
ip rule
sudo ufw status verbose
sudo iptables-save
sudo iptables-legacy-save -t mangle
```

Verify the home public IP matches the CGW definition. Use a LAN-local administration path; do not open SSH to the internet. Confirm which route table is actually associated with the EC2 subnet.

## 2. Create a bounded, static VPN

Prepare a root/private mode-0600 `vpn-options.json` through a secure local process. Set static routing, disable acceleration, configure the home/VPC selectors, and install freshly generated PSKs. Never paste a real PSK into command history. The lab selected IKEv2 and used the standard VPN service.

```bash
# A restricted response avoids printing credential-bearing customer-gateway XML.
aws ec2 create-vpn-connection \
  --customer-gateway-id <CGW_ID> --vpn-gateway-id <VGW_ID> \
  --type ipsec.1 --options file://vpn-options.json --region us-east-1 \
  --query 'VpnConnection.{Id:VpnConnectionId,State:State,Tunnels:Options.TunnelOptions[].{Ip:OutsideIpAddress,Cidr:TunnelInsideCidr}}'

aws ec2 create-vpn-connection-route \
  --vpn-connection-id <NEW_VPN_ID> --destination-cidr-block 192.168.1.0/24 \
  --region us-east-1
```

AWS returns new outside endpoint addresses on rebuild. Read new inside addressing rather than assuming the sample CIDRs are available. Preserve the protected key material only as long as required for secure installation. Do not enable acceleration, a Transit Gateway, or new log/alarm resources without evaluating their costs.

## 3. Linux routing and firewall

Review the three reference files: `ipsec.conf.example`, `cloudbiz-vti-setup.example`, and `cloudbiz-vti-updown.example`. The setup reference documents the exact fixed-host forwarding design; adapt it before use. It is not an idempotent production configuration manager.

- Install the route hook root-owned and executable. Keep configuration/secret files root-owned with mode 0600.
- Disable the optional forecast plugin in `/etc/strongswan.d/charon/forecast.conf` for this explicit VTI design.
- Use new AWS endpoint addresses in the VTI setup, firewall rules, and IPsec configuration.
- Review existing ownership of policy priority 100 and any table-220 route before changing them.
- Persist interface creation before strongSwan and use the CHILD-SA up/down hook for route lifetime.
- Retain LAN-local SSH access and the existing default internet route.

```bash
sudo systemctl restart strongswan-starter
# Wait for the daemon/control socket to be ready before interpreting status.
sudo ipsec statusall
ip route show 10.20.0.0/16
sudo iptables-legacy-save -t mangle
```

A nonzero status immediately after restart does not, by itself, prove authentication failed. Investigate journal output and readiness before repeating mutating setup scripts.

## 4. AWS and home return routes

```bash
aws ec2 create-route --route-table-id <TEST_ROUTE_TABLE_ID> \
  --destination-cidr-block 192.168.1.0/24 --gateway-id <VGW_ID> --region us-east-1

# macOS, only on the designated test host after confirming no conflicting route:
sudo route -n add -net 10.20.0.0/16 192.168.1.203
```

Add only necessary EC2 test rules: ICMP from the two designated local /32 addresses, ICMP egress to those /32s, and TCP 9000 egress to the proof listener's /32. Preserve the original web rules. Keep SSH ingress closed. Track every newly created rule ID for exact teardown.

For SSM, the lab temporarily attached a dedicated EC2 instance profile with `AmazonSSMManagedInstanceCore`. Its role was restricted to EC2 service assumption. Check for existing profiles; do not overwrite another role. Start the existing stopped test EC2 only within the approved cost window, wait for SSM Online, and schedule a shutdown before the deadline.

## 5. Test and observe

Use the commands in README.md and the acceptance checks in VALIDATION.md. Start an independent private HTTP observer before changing tunnel state. On Ubuntu:

```bash
# Confirm the other tunnel has an installed CHILD SA before each down command.
sudo ipsec down Tunnel1
# Verify route withdrawal and actual traffic over Tunnel2.
sudo ipsec up Tunnel1
# Wait for installation and successful traffic before proceeding.
sudo ipsec down Tunnel2
# Allow convergence, record failures, and prove late-phase traffic on Tunnel1.
sudo ipsec up Tunnel2
```

Always restore both tunnels in a finally/recovery path if an automated test is interrupted. Never intentionally stop both at once in this scenario. Observe private requests, route choice, per-interface/SA counters, AWS-origin tests, and native AWS/VPN metrics. Actual measured convergence belongs in the report.

## 6. Retire the temporary lab

```bash
aws ec2 delete-vpn-connection --vpn-connection-id <THIS_SESSION_VPN_ID> --region us-east-1
aws ec2 stop-instances --instance-ids <EXISTING_TEST_INSTANCE_ID> --region us-east-1

aws ec2 describe-vpn-connections --vpn-connection-ids <THIS_SESSION_VPN_ID> \
  --query 'VpnConnections[].{Id:VpnConnectionId,State:State}' --region us-east-1
aws ec2 describe-instances --instance-ids <EXISTING_TEST_INSTANCE_ID> \
  --query 'Reservations[].Instances[].{State:State.Name,PublicIp:PublicIpAddress}' --region us-east-1
```

Delete only this session's temporary VPN. Remove only tracked lab rule IDs and the exact lab return route. Disassociate and remove only the dedicated temporary SSM profile/role after checking it has not acquired other uses. Restore local forwarding and remove only lab-owned interfaces, routes, marks, services, and proof listener. Retire dedicated audit access last.

```bash
# macOS: remove the exact lab route; do not delete a different/default route.
sudo route -n delete -net 10.20.0.0/16 192.168.1.203
```

Verify final states and remaining retained storage. Preserve VPC, gateways, original EC2/EBS, original web/default routes, and the separate portfolio. Rebuild configuration requires fresh endpoint details and fresh keys.
