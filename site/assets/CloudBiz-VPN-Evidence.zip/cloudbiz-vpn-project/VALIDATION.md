# Validation and final QA — 30 October 2026

**Result: functional private connectivity and administrative failover/recovery verified. The temporary environment was then decommissioned.**

## Actual traffic results

| Check | Observed result |
|---|---|
| Mac → EC2 private HTTP | HTTP 200; CloudBiz page content verified |
| Mac → EC2 private ICMP | 4/4 replies |
| Ubuntu → EC2 private HTTP | HTTP 200 |
| AWS → Ubuntu ICMP | 4/4 replies |
| AWS → Ubuntu proof HTTP | Expected harmless marker returned |
| AWS → Mac ICMP | 4/4 replies in baseline |
| 1400-byte IPv4 test | 3/3 DF replies: payload 1372 + IPv4/ICMP headers |
| Private SSH 22 | TCP connection timed out; no SSH ingress in EC2 SG |
| AWS final telemetry | Both tunnel endpoints UP before teardown |
| Linux final control plane | Both CHILD SAs installed before teardown |
| Recurring legacy marks | Absent after tunnel shutdown/re-establishment; forecast unloaded |

## Controlled failover

Independent HTTP probes ran during the root-controlled sequence, 10:55–11:03 Chicago time (UTC−05:00).

| Observer phase | HTTP 200 | Timeout/failure |
|---|---:|---:|
| Both tunnels installed | 79 | 0 |
| Only Tunnel 2 | 101 | 0 |
| Tunnel 1 restored / observer transition | 48 | 2 |
| Only Tunnel 1 | 57 | 11 |
| Both tunnels restored | 49 | 0 |
| **Total** | **334** | **13** |

![Measured private HTTP results](evidence/failover-http.png)

All 13 failures form one consecutive run around the administrative shutdown of Tunnel 2 and transition to Tunnel 1. The last successful request started at 11:00:30.436; the next successful request started at 11:00:58.244, a **27.81-second gap between successful probes**. Sampling and request timeout resolution mean this is an observed probe gap, not an exact network outage duration.

Phase labels are sampled by the observer and can lag control transitions; two failures therefore appear under the prior observer label. The root event log records the down action after the command and a two-second readiness check. These are not two separate outages.

The first AWS-origin probe immediately after the Tunnel 2 shutdown failed. A later probe, with **only Tunnel 1 installed before and after the test**, returned the proof HTTP marker and received 3/3 ICMP replies from the Mac. Both tunnels then recovered, with 49/49 successful HTTP observations in the final phase.

The delay is consistent with path convergence in the static-VPN setup; the precise internal AWS convergence mechanism was not instrumented. No firewall rewrite was required during the transition. Do not describe this result as zero downtime, an HA SLA, BGP failover, or a simulated physical ISP outage.

![AWS console after recovery](evidence/aws-tunnels-recovered.png)

This real AWS console screenshot was cropped to omit the account header and home public IP. It shows tunnel status at capture time, before deletion. The screenshot alone is not the traffic test; the JSON records provide traffic and route evidence.

## Monitoring and records

- Local health collection every five seconds; independent per-request HTTP observations.
- Selected sanitized strongSwan negotiation/lifecycle journal lines.
- AWS-origin SSM test results at each phase, including the initially unsuccessful probe and the later successful Tunnel-1-only probe.
- Native CloudWatch `TunnelState`, `TunnelDataIn`, and `TunnelDataOut` samples, plus per-tunnel AWS telemetry.
- No new paid CloudWatch alarm or AWS tunnel log group was created. Console tunnel logging remained disabled; local logs and native metrics were used.

## Earlier failures retained in the history

The first 27 October failover attempt produced 189 unsuccessful Mac HTTP requests. The loaded forecast plugin recreated legacy packet-marking rules on CHILD SA events. It was disabled for this VTI design. The final 30 October audit shows no project rules in legacy mangle after repeated tunnel events.

The first 30 October traffic baseline ran before the rebuilt AWS connection was fully ready and timed out. The repeated complete baseline succeeded. The resume script also checked the strongSwan socket too early after restart and exited after applying its changes; subsequent inspection verified the daemon and both SAs. These failures were not used as success evidence.

## Teardown QA

- VPN connection state `deleted` confirmed by API.
- Existing EC2 `stopped`, no public IPv4, no instance profile.
- Temporary SSM role/profile verified absent.
- Exactly five lab SG rule IDs removed. Existing HTTP/HTTPS ingress and original HTTPS egress preserved; SSH ingress was not reopened.
- Only the lab home-return route removed. Original VPC local/default-IGW routes preserved.
- Ubuntu VTIs, lab forwarding chain/marks/MSS rules, and project priority-100 rule absent; forwarding restored to 0; lab units disabled; proof listener stopped.
- The first cleanup pass missed the priority-100 rule because of whitespace matching. The final read-only check caught it; the exact rule was removed and absence verified.
- Mac project route absent; home internet gateway preserved.
- Dedicated temporary audit SSH key removed; a key-only login attempt then failed as expected. Other authorized keys and LAN password SSH access were preserved.
- VPC, VGW, CGW, original EC2 and its encrypted 8 GiB gp3 EBS volume retained. The separate portfolio was not modified.

EBS storage remains billable while retained. Earlier VPN/instance charges and other account resources can appear later in billing. No claim of a zero-dollar account balance is made.

## Review limitations

This validates the designated Mac/Ubuntu/EC2 paths and two-tunnel administrative failover. It does not validate other LAN devices, private-subnet workloads, databases, load tests, tunnel rekey over an entire lifetime, physical ISP outage recovery, BGP, or production service objectives. Configuration examples are sanitized references and require adaptation and fresh keys for a rebuild.
